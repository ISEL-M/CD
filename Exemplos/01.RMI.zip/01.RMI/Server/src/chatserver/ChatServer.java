package chatserver;

import chatcontract.IChatCallback;
import chatcontract.IChatService;


import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class ChatServer implements IChatService {
    static String serverIP = "localhost";
    static int registerPort = 7000;
    static int svcPort = 7001;
    static ChatServer svc = null;

    public static void main(String[] args) throws Exception {
        try {
            Properties props = System.getProperties();
            props.put("java.rmi.server.hostname", serverIP);

            // create instance of server object
            svc = new ChatServer();

            // make server object available to be called in port svcPort
            IChatService stubSvc = (IChatService) UnicastRemoteObject.exportObject(svc, svcPort);

            // register server object in lookup service for clients to find it
            Registry registry = LocateRegistry.createRegistry(registerPort);
            registry.rebind("ChatServer", stubSvc);

            System.out.println("Server ready: Press any key to finish server");
            java.util.Scanner scanner = new java.util.Scanner(System.in);
            String line = scanner.nextLine();
            System.exit(0);
        } catch (RemoteException e) {
            e.printStackTrace();
        } catch (Exception ex) {
            System.err.println("Server unhandled exception: " + ex.toString());
        }
    }

    private Map<String, IChatCallback> clients= new ConcurrentHashMap<>();

    public ChatServer() {
        //clients = new HashMap<>();
    }

    @Override
    public void registerClient(String clientName, IChatCallback clientCallBack) throws RemoteException {
        synchronized (clients) {
            if (!clients.containsKey(clientName))
                clients.put(clientName, clientCallBack);
            else throw new RemoteException("Esse nome de cliente já existe");
        }
    }


    @Override
    public void sendMessage(String senderName, String msg) throws RemoteException {
        if (!clients.containsKey(senderName))
            throw new RemoteException("Unregister client cannot send messages");
        //synchronized (clients) {
            for (String clientDestName : clients.keySet())
                try {
//                    try {
//                        Thread.sleep(8*1000);
//                    } catch (InterruptedException e) {
//                        e.printStackTrace();
//                    }
                    clients.get(clientDestName).message(senderName, msg);
                } catch (RemoteException ex) {
                    // error calling client. remove client and callback
                    System.out.println("Client "+clientDestName+" removed");
                    clients.remove(clientDestName);
                }
        //}
    }
}
