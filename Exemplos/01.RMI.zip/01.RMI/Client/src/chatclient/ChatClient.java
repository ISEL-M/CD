package chatclient;

import chatcontract.IChatCallback;
import chatcontract.IChatService;


import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Properties;
import java.util.Scanner;

public class ChatClient {
    static String serverIP="localhost";
    static String LocalIP="localhost";
    static int registerPort = 7000;
    public static void main(String[] args) {
        try {
            Registry registry = LocateRegistry.getRegistry(serverIP,registerPort);
            IChatService svc=(IChatService)registry.lookup("ChatServer");
            System.out.print("Enter user name: ");
            Scanner input = new Scanner(System.in); String name = input.nextLine();

            IChatCallback callback = new MyCallback();
            Properties props = System.getProperties();
            props.put("java.rmi.server.hostname", LocalIP); // force unicast with local IP
            IChatCallback stubCallBack=(IChatCallback) UnicastRemoteObject.exportObject(callback, 0);
            svc.registerClient(name, stubCallBack);

            for (int i=0; i < 50; i++) {
                svc.sendMessage(name, "msg from " + name);
                Thread.sleep(2 * 100);
            }
//            System.out.println("Enter lines or the word \"exit\"");
//            while (true) {
//                String line = input.nextLine(); if (line.equals("exit")) break;
//                svc.sendMessage(name, line);
//            }
        } catch (RemoteException e) {
            e.printStackTrace();
        } catch (Exception ex) {
            System.err.println("Client unhandled exception: " + ex.toString());
            ex.printStackTrace();
        }
        System.exit(-1);
    }
}
