package chatclient;

import chatcontract.IChatCallback;

import java.rmi.RemoteException;

public class MyCallback implements IChatCallback {

    @Override
    public void message(String senderName, String msg) throws RemoteException {
        System.out.println("[sender:" + senderName + "] " + msg);
    }
}
