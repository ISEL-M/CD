package chatcontract;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface IChatService extends Remote {
    public void registerClient(String clientName, IChatCallback callback) throws RemoteException;
    public void sendMessage(String senderName, String message) throws RemoteException;
}
