package chatcontract;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface IChatCallback extends Remote {
    public void message(String sender, String msg) throws RemoteException;
}
